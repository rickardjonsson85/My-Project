import React from "react";
const pageNum = ({ property }) => {
  const { id, image } = property;
  return (
    <div id={`pageNum-${id}`}>
      <img className="carusellimages" src={image} />
    </div>
  );
};

export default pageNum;
