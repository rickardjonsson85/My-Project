import image1 from "../../img/my/01.jpg";
import image2 from "../../img/my/02.jpg";
import image3 from "../../img/my/03.jpg";
import image4 from "../../img/my/04.jpg";
import image5 from "../../img/my/05.jpg";

const data = [
  {
    id: 0,
    image: image1,
    title: "bild1"
  },
  {
    id: 1,
    image: image2,
    title: "bild2"
  },
  {
    id: 2,
    image: image3,
    title: "bild3"
  },
  {
    id: 3,
    image: image4,
    title: "bild4"
  },
  {
    id: 4,
    image: image5,
    title: "bild5"
  }
];
export default data;
